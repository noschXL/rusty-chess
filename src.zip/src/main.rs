mod engine;
mod gui;

use crate::engine::constants::*;

#[macroquad::main("MyGame")]
async fn main() {

    let piece_asset = gui::init().await;
    let mut board = engine::board::Board::new_empty();
    board.set_piece_data_at(0, piece_constants::WHITE | piece_constants::QUEEN);
    println!("{board:?}");
    
    loop {
        gui::render(&piece_asset, &board).await;
    }
}
